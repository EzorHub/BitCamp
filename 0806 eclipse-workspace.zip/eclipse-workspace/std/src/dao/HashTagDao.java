package dao;

public class HashTagDao {

}
