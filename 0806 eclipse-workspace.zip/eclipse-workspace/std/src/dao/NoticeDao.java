package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import db.ConnectionProvider;
import vo.NoticeVo;

public class NoticeDao {
	public ArrayList<NoticeVo> listAllNotice(){
		ArrayList<NoticeVo> list = new ArrayList<NoticeVo>();
		try {
			String sql ="select * from notice";
			Connection conn = ConnectionProvider.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				NoticeVo vo = new NoticeVo();
				vo.setNotice_no(rs.getInt(1));
				vo.setNotice_title(rs.getString(2));
				vo.setNotice_content(rs.getString(3));
				list.add(vo);				
			}
			ConnectionProvider.close(conn, stmt, rs);
			
		}catch (Exception e) {
	        System.out.println(e.getMessage());
		}
		return list;		
			
	}
	
	// type�̶� keyword�� ��� �˻��ؾ�����? ���ǹ�ó��,,?
	// sql���� %����% ~~like %% �ؾ߰�?
	public ArrayList<NoticeVo> searchNotice(int type, String keyword){
		ArrayList<NoticeVo> list = new ArrayList<NoticeVo>();
		try {
			String sql="select * from notice where title like %"+'?'+"% and content like %"+'?'+"%";
			Connection conn = ConnectionProvider.getConnection();
			PreparedStatement pstmt =conn.prepareStatement(sql);
			pstmt.setInt(1, type);
			pstmt.setString(2, keyword);
			ResultSet rs = pstmt.executeQuery();
			//while? if? �˻��� �� �ǿ� ���� ����ϱ� if�� ����
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return list;
	}
	
	public int deleteNotice(int notice_no) {
		int re =-1;
		try {
			String sql ="delete notice where no=?";
			Connection conn = ConnectionProvider.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, notice_no);
			re =pstmt.executeUpdate();
			
			ConnectionProvider.close(conn, pstmt);
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return re;
	}
	
	public int updateNotice(NoticeVo vo) {
		int re= -1;
		try {
			String sql ="update notice set title=?,content=?";
			Connection conn = ConnectionProvider.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, vo.getNotice_title());
			pstmt.setString(2, vo.getNotice_content());
			re =pstmt.executeUpdate();
			
			ConnectionProvider.close(conn, pstmt);
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return re;
	}
	
	public int insertNotice(NoticeVo vo) {
		int re = -1;
		try {
			//��¥- �켱�� sysdate
			//admin_no- ��¥�� �ϳ��� �������Ѿ����ٵ�..!�̸� ������ ����������ϴ���?�켱�� "?"
			String sql ="insert into notice values((select nvl(max(notice_no),0)+1 from notice),?,?,sysdate,0,1)";
			Connection conn = ConnectionProvider.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getNotice_title());
			pstmt.setString(2, vo.getNotice_content());
			
			re = pstmt.executeUpdate();
			ConnectionProvider.close(conn, pstmt);
					
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return re;
	}
	
	public NoticeVo detailNotice(int notice_no) {
		NoticeVo vo = new NoticeVo();
		try {
			String sql = "select * from notice where no=?";
			Connection conn = ConnectionProvider.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, notice_no);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				vo.setNotice_no(rs.getInt(1));
				vo.setNotice_title(rs.getString(2));
				vo.setNotice_content(rs.getString(3));
				vo.setWrite_date(rs.getString(4));
				vo.setHits(rs.getInt(5));
				vo.setAdmin_no(rs.getInt(6));
			}
			ConnectionProvider.close(conn, pstmt);
					
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return vo;
	}
	
	
}
