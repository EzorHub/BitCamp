package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import db.ConnectionProvider;
import vo.QAVo;

public class QADao { //qa�� ���� ������ �������?
	
	
	public ArrayList<QAVo> listQa() {
		ArrayList<QAVo> list = new ArrayList<QAVo>();
		try {
			String sql ="select * from qa";
			Connection conn = ConnectionProvider.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				QAVo vo = new QAVo();
				vo.setQa_no(rs.getInt(1));
				vo.setQa_title(rs.getString(2));
				vo.setQa_write_date(rs.getString(3));
				vo.setIsAnswered(rs.getString(4)); //*
				vo.setQa_content(rs.getString(5));
				vo.setQa_answer_date(rs.getString(6));
				vo.setQa_answer(rs.getString(7));
				vo.setCust_no(rs.getInt(8));
				vo.setAdmin_no(rs.getInt(9));
		
				list.add(vo);	
			}
			ConnectionProvider.close(conn, stmt, rs);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return list;
	}
	//***
	public ArrayList<QAVo> searchQa(int type, String keyword){
		ArrayList<QAVo> list = new ArrayList<QAVo>();
		try {
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return list;
	}
	public QAVo detailQa(int qa_no) {
		QAVo vo = new QAVo();
		try {
			String sql = "select * from notice where no=?";
			Connection conn = ConnectionProvider.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, qa_no);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				vo.setQa_no(rs.getInt(1));
				vo.setQa_title(rs.getString(2));
				vo.setQa_write_date(rs.getString(3));
				vo.setIsAnswered(rs.getString(4));
				vo.setQa_content(rs.getString(5));
				vo.setQa_answer_date(rs.getString(6));
				vo.setQa_answer(rs.getString(7));
				vo.setCust_no(rs.getInt(8));
				vo.setAdmin_no(rs.getInt(9));
				
			}
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return vo;
	}
	
	public int insertQa(QAVo vo) {
		int re = -1;
		try {
			//��¥- �켱�� sysdate
			//admin_no- ��¥�� �ϳ��� �������Ѿ����ٵ�..!�̸� ������ ����������ϴ���?�켱�� "?"
			String sql ="insert into notice values((select nvl(max(qa_no),0)+1 from qa),?,sysdate,'false',?,(sysdate+1),null,?,?)";
			Connection conn = ConnectionProvider.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getQa_title());			
			pstmt.setString(2, vo.getQa_content());
			pstmt.setString(3, vo.getQa_answer());
			pstmt.setInt(4, vo.getCust_no());
			pstmt.setInt(5, vo.getAdmin_no());
			re = pstmt.executeUpdate();
			ConnectionProvider.close(conn, pstmt);
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return re;
	}
	//�亯 ���� ���Ŀ��� ��������? �亯 �ޱ� �������� ���� ����?
	public int updateQa(QAVo vo) {
		int re = -1;
		try {
			String sql ="update notice set title=?,content=?";
			Connection conn = ConnectionProvider.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);			
			pstmt.setString(1, vo.getQa_title());
			pstmt.setString(2, vo.getQa_content());
			re =pstmt.executeUpdate();
			
			ConnectionProvider.close(conn, pstmt);
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return re;
	}
	//**
	public int updateQaReply(String answer) {
		int re = -1;
		try {
			String sql ="update qa set isanswered='true',qa_answer_date=sysdate ,qa_answer=?";
			Connection conn = ConnectionProvider.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);			
			pstmt.setString(2, answer);
			re =pstmt.executeUpdate();
			
			ConnectionProvider.close(conn, pstmt);
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return re;
	}

}
