package dao;

import java.util.ArrayList;

import vo.StdApplyVo;

public class StdApplyDao {
	public int insertStdApply() {
		int re = -1;
		try {
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return re;
	}
	public ArrayList<StdApplyVo> detailStdApply(){
		ArrayList<StdApplyVo> list = new ArrayList<StdApplyVo>();
		return list;
	}
}
