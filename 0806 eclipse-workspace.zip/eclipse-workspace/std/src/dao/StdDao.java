package dao;

import java.util.ArrayList;

import vo.StdVo;

public class StdDao {
	public ArrayList<StdVo> searchStd(String loc1, String loc2, String keyword){
		ArrayList<StdVo> list = new ArrayList<StdVo>();
		try {
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return list;
	}
	
	public int updateStd(StdVo vo) {
		int re = -1;
		try {
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return re;
	}
	
	public ArrayList<StdVo> listAllStd(){
		ArrayList<StdVo> list = new ArrayList<StdVo>();
		try {
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return list;
	}
	public StdVo detailStd(int std_no) {
		StdVo vo = new StdVo();
		try {
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return vo;
	}
	
	public int insertStd() {
		int re = -1;
		try {
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return re;
	}
	
	public ArrayList<StdVo> listJoinStd(int cust_no) {
		ArrayList<StdVo> list = new ArrayList<StdVo>();
		try {
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return list;
	}
	public ArrayList<StdVo> listWaitStd(int cust_no) {
		ArrayList<StdVo> list = new ArrayList<StdVo>();
		try {
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return list;
	}
	public ArrayList<StdVo> listEndStd(int cust_no) {
		ArrayList<StdVo> list = new ArrayList<StdVo>();
		try {
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return list;
	}
	public ArrayList<StdVo> listEstablishStd(int cust_no) {
		ArrayList<StdVo> list = new ArrayList<StdVo>();
		try {
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return list;
	}
	public ArrayList<StdVo> listProgressStd(int cust_no) {
		ArrayList<StdVo> list = new ArrayList<StdVo>();
		try {
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return list;
	}
	
	
	
}
