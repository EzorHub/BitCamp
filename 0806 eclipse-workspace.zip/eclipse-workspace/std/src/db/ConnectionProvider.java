package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ConnectionProvider {

	public static Connection getConnection() {
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "c##std_pick", "1234");
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return conn;
	}
	public static void close(Connection conn, Statement stmt) {
		try {		
		if(conn != null) {
			conn.close();
		}
		if(stmt != null) {
			stmt.close();
		}
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	public static void close(Connection conn, Statement stmt, ResultSet rs) {
		try {
		if(conn != null) {
			conn.close();
		}
		if(stmt != null) {
			stmt.close();
		}
		if(rs != null) {
			rs.close();
		}
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
