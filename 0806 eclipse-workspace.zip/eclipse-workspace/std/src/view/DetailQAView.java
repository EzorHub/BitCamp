package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class DetailQAView extends JPanel {
	JButton btn_notice;
	JButton btn_qa;
	
	JLabel lb_qa;
	JLabel lb_title;
	JLabel lb_writer;
	JLabel lb_regdate;
	JLabel lb_result;
	
	JLabel lb_answer_date;
	JLabel lb_answer;
	
	JTextField tf_title;
	JTextField tf_writer;
	JTextField tf_regdate;
	JTextField tf_result;
	JTextArea ta_content;
	JTextField tf_answer_date;
	JTextField tf_answer;
	
	JButton btn_delete;
	JButton btn_list;
	
	
	
	public DetailQAView() {
		btn_notice = new JButton("��������");
		btn_qa = new JButton("Q&A");
		btn_delete = new JButton("����");
		btn_list = new JButton("���");
		
		JPanel p_btn = new JPanel();
		p_btn.setLayout(new GridLayout(1,2));
		p_btn.add(btn_notice);
		p_btn.add(btn_qa);
		
		
		lb_qa = new JLabel("Q & A");
		lb_title = new JLabel("����");
		tf_title = new JTextField(20);
		lb_writer = new JLabel("�ۼ���");
		tf_writer = new JTextField(20);
		lb_regdate = new JLabel("�����Ͻ�");
		tf_regdate = new JTextField(15);
		lb_result = new JLabel("ó�����");
		tf_result = new JTextField(10);
		ta_content = new JTextArea(10, 50);
		JScrollPane jsp = new JScrollPane(ta_content);
				
		lb_answer_date = new JLabel("�亯�Ͻ�");
		tf_answer_date = new JTextField(15);
		lb_answer = new JLabel("�亯����");
		tf_answer = new JTextField(30);
		
		JPanel p_info = new JPanel();
		p_info.setLayout(new GridLayout(2,4));
		p_info.add(lb_title);
		p_info.add(tf_title);
		p_info.add(lb_writer);
		p_info.add(tf_writer);
		p_info.add(lb_regdate);
		p_info.add(tf_regdate);
		p_info.add(lb_result);
		p_info.add(tf_result);	
		
		//JPanel p_cont = new JPanel(new GridLayout(1, 2));
		//p_cont.add(lb_con)
		
		JPanel p_reply = new JPanel();
		p_reply.setLayout(new GridLayout(2, 4));
		p_reply.add(lb_answer_date);
		p_reply.add(tf_answer_date);
		p_reply.add(lb_answer);
		p_reply.add(tf_answer);
		
		JPanel p_btn_down = new JPanel();
		p_btn_down.setLayout(new FlowLayout());
		p_btn_down.add(btn_delete);
		p_btn_down.add(btn_list);
		
		setLayout(new BorderLayout());
		add(p_btn, BorderLayout.NORTH);
		JPanel p_all = new JPanel(new BorderLayout());
		p_all.add(p_info, BorderLayout.NORTH);
		p_all.add(jsp, BorderLayout.CENTER);
		p_all.add(p_reply, BorderLayout.SOUTH);
		
		add(p_all, BorderLayout.CENTER);
		add(p_btn_down, BorderLayout.SOUTH);
		
	}
}
