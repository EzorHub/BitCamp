package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class ListQAView extends JPanel{
	JButton btn_notice;
	JButton btn_qa;
	JLabel lb_title;
	JComboBox<String> cb_type;
	String[] type = {"��ü", "����", "����"};
	JTextField tf_search;
	JButton btn_search;
	Vector<String> colName;
	Vector<Vector<String>> rowData;
	public ListQAView() {
		setLayout(new BorderLayout());
		
		btn_notice = new JButton("��������");
		btn_qa = new JButton("Q&A");
		
		lb_title = new JLabel("Q&A");
		cb_type = new JComboBox<String>(type);
		tf_search = new JTextField(50);
		btn_search = new JButton("�˻�");
		colName = new Vector<String>();
		rowData = new Vector<Vector<String>>();
		
		colName.add("no");
		colName.add("title");
		colName.add("writer");
		colName.add("condition");
		colName.add("write date");
		colName.add("hits");
		
		JTable table = new JTable(rowData, colName);
		JScrollPane jsp = new JScrollPane(table);
		
		JPanel p_btn = new JPanel(new GridLayout(1,2));
		p_btn.add(btn_notice);
		p_btn.add(btn_qa);
		
				
		JPanel p_search = new JPanel();
		p_search.setLayout(new FlowLayout());
		p_search.add(cb_type);
		p_search.add(tf_search);
		p_search.add(btn_search);
		
		
		JPanel p_title = new JPanel();
		p_title.setLayout(new BorderLayout());
		p_title.add(lb_title, BorderLayout.NORTH);
		p_title.add(p_search, BorderLayout.CENTER);
		
		JPanel p_up = new JPanel();
		p_up.setLayout(new BorderLayout());
		p_up.add(p_btn, BorderLayout.NORTH);
		p_up.add(p_search, BorderLayout.CENTER);
		
		add(p_up, BorderLayout.NORTH);
		add(jsp, BorderLayout.CENTER);
		
		
		
		
	}
}
