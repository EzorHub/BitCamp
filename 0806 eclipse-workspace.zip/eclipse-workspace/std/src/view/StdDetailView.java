package view;

import javax.swing.JPanel;

public class StdDetailView extends JPanel{
	public StdDetailView() {
		
	}
}
