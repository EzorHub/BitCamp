package view;

import javax.swing.JFrame;

public class TestFrame extends JFrame {
	public TestFrame() {
		
		//StdOpenView open = new StdOpenView();
		//add(open);
		//ListQAView list_qa = new ListQAView();
		//add(list_qa);
		DetailQAView qa = new DetailQAView();
		add(qa);
		
		setSize(1700, 900);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		new TestFrame();
		
		
	}

}
