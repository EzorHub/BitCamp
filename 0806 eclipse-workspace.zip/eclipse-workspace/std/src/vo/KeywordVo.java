package vo;

public class KeywordVo {

	int key_no;
	String key_name;
	String key_loc;
	int cust_no;
	
	public int getKey_no() {
		return key_no;
	}
	public void setKey_no(int key_no) {
		this.key_no = key_no;
	}
	public String getKey_name() {
		return key_name;
	}
	public void setKey_name(String key_name) {
		this.key_name = key_name;
	}
	public String getKey_loc() {
		return key_loc;
	}
	public void setKey_loc(String key_loc) {
		this.key_loc = key_loc;
	}
	public int getCust_no() {
		return cust_no;
	}
	public void setCust_no(int cust_no) {
		this.cust_no = cust_no;
	}
	public KeywordVo(int key_no, String key_name, String key_loc, int cust_no) {
		super();
		this.key_no = key_no;
		this.key_name = key_name;
		this.key_loc = key_loc;
		this.cust_no = cust_no;
	}
	public KeywordVo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
