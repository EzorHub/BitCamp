package vo;

import java.util.Date;

public class NoticeVo {

	int notice_no;
	String notice_title;
	String notice_content;
	String write_date;
	int hits;
	int admin_no;
	
	public int getNotice_no() {
		return notice_no;
	}
	public void setNotice_no(int notice_no) {
		this.notice_no = notice_no;
	}
	public String getNotice_title() {
		return notice_title;
	}
	public void setNotice_title(String notice_title) {
		this.notice_title = notice_title;
	}
	public String getNotice_content() {
		return notice_content;
	}
	public void setNotice_content(String notice_content) {
		this.notice_content = notice_content;
	}
	public String getWrite_date() {
		return write_date;
	}
	public void setWrite_date(String write_date) {
		this.write_date = write_date;
	}
	public int getHits() {
		return hits;
	}
	public void setHits(int hits) {
		this.hits = hits;
	}
	public int getAdmin_no() {
		return admin_no;
	}
	public void setAdmin_no(int admin_no) {
		this.admin_no = admin_no;
	}
	public NoticeVo(int notice_no, String notice_title, String notice_content, String write_date, int hits,
			int admin_no) {
		super();
		this.notice_no = notice_no;
		this.notice_title = notice_title;
		this.notice_content = notice_content;
		this.write_date = write_date;
		this.hits = hits;
		this.admin_no = admin_no;
	}
	public NoticeVo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
