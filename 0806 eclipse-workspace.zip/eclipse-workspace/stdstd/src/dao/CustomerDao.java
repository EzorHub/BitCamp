
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import vo.CustomerVo;

import db.ConnectionProvider;

public class CustomerDao {
	public boolean logIn(String id, String pwd) {
		boolean flag = false;
		try {

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return flag;
	}

	public int insertCustomer(CustomerVo vo) {
		int re = -1;
		try {
			// cust_q, cust_a�� ���� ó��?
			String sql = "insert into customer values((selecet nvl(max(cust_no),0)+1 from customer),?,?,?,?,?,?,?,?,? )";
			Connection conn = ConnectionProvider.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getCust_name());
			pstmt.setString(2, vo.getCust_nick());
			pstmt.setString(3, vo.getPhone());
			pstmt.setString(4, vo.getAddr());
			pstmt.setString(5, vo.getEmail());
			pstmt.setString(6, vo.getId());
			pstmt.setString(7, vo.getPwd());
			pstmt.setString(8, vo.getCust_q());
			pstmt.setString(9, vo.getCust_a());

			re = pstmt.executeUpdate();

			ConnectionProvider.close(conn, pstmt);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return re;
	}

	public int updateCustomer(CustomerVo vo) {
			int re = -1;
			try {
				
			}catch (Exception e) {
				System.out.println(e.getMessage());
			}
			return re;
		}

	public CustomerVo detailCustomer(int cust_no) {
			CustomerVo vo = new CustomerVo();
			try {
				
			}catch (Exception e) {
				System.out.println(e.getMessage());
				}
			return vo;
			}
	
	
}

