package dao;

public class StdApplyDao {

}
