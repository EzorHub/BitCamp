package dao;

public class StdDao {

}
