package vo;

import java.util.Date;

public class QAVo {
	int qa_no;
	String qa_title;
	String qa_write_date;
	String isAnswered;
	String qa_content;
	String qa_answer_date;
	String qa_answer;
	int cust_no;
	int admin_no;

	
	public int getQa_no() {
		return qa_no;
	}


	public void setQa_no(int qa_no) {
		this.qa_no = qa_no;
	}


	public String getQa_title() {
		return qa_title;
	}


	public void setQa_title(String qa_title) {
		this.qa_title = qa_title;
	}


	public String getQa_write_date() {
		return qa_write_date;
	}


	public void setQa_write_date(String qa_write_date) {
		this.qa_write_date = qa_write_date;
	}


	public String getIsAnswered() {
		return isAnswered;
	}


	public void setIsAnswered(String isAnswered) {
		this.isAnswered = isAnswered;
	}


	public String getQa_content() {
		return qa_content;
	}


	public void setQa_content(String qa_content) {
		this.qa_content = qa_content;
	}


	public String getQa_answer_date() {
		return qa_answer_date;
	}


	public void setQa_answer_date(String qa_answer_date) {
		this.qa_answer_date = qa_answer_date;
	}


	public String getQa_answer() {
		return qa_answer;
	}


	public void setQa_answer(String qa_answer) {
		this.qa_answer = qa_answer;
	}


	public int getCust_no() {
		return cust_no;
	}


	public void setCust_no(int cust_no) {
		this.cust_no = cust_no;
	}


	public int getAdmin_no() {
		return admin_no;
	}


	public void setAdmin_no(int admin_no) {
		this.admin_no = admin_no;
	}


	public QAVo(int qa_no, String qa_title, String qa_write_date, String isAnswered, String qa_content,
			String qa_answer_date, String qa_answer, int cust_no, int admin_no) {
		super();
		this.qa_no = qa_no;
		this.qa_title = qa_title;
		this.qa_write_date = qa_write_date;
		this.isAnswered = isAnswered;
		this.qa_content = qa_content;
		this.qa_answer_date = qa_answer_date;
		this.qa_answer = qa_answer;
		this.cust_no = cust_no;
		this.admin_no = admin_no;
	}


	public QAVo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
