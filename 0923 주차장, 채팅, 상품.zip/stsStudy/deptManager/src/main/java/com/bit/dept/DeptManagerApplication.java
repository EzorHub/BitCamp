package com.bit.dept;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeptManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeptManagerApplication.class, args);
	}

}
