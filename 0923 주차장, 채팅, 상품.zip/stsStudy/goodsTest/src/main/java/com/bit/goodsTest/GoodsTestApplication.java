package com.bit.goodsTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoodsTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoodsTestApplication.class, args);
	}

}
