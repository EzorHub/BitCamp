package com.bitShop.controller;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bitShop.CEncrypt;
import com.bitShop.dao.BitDao;
import com.bitShop.vo.BitMemberVo;

import kr.co.youiwe.webservice.ServiceSMSSoapProxy;

@Controller
public class BitMemberController {
     
    @Autowired
    private BitDao bitdao;
     
    public void setBitdao(BitDao bitdao) {
		this.bitdao = bitdao;
	}
 
    @ResponseBody //없으면 뷰페이지를 찾게됨
    @RequestMapping("/sendAuthNumber")
    public String sendAuthNumber(String tel)
    {
        String r = "";
        Random rand = new Random();
        for(int i=1;i<=5;i++)
        {
           r += rand.nextInt(10)+"";
        }       
        System.out.println(r);
         
        String smsID= "rola";   
        String smsPW="bit123400";
        //01025598279
         
        ServiceSMSSoapProxy sendsms = new ServiceSMSSoapProxy();
        try{
         
        String senderPhone= "01068689295";      
        String receivePhone= tel;
        String smsContent= "다음의 인증번호를 입력해 주세요.["+r+"]";
        String test1 = (smsID+smsPW+receivePhone);
        CEncrypt encrypt = new CEncrypt("MD5",test1);
        java.lang.String send=sendsms.sendSMS(smsID,encrypt.getEncryptData(), senderPhone, receivePhone, smsContent);
        System.out.println("결과코드:"+send);
        }catch(Exception e){
        System.out.println("Exception in main:" +e);
        }
        return r;
    }
    
    
    @ResponseBody
    @RequestMapping(value = "/insertMember", method = RequestMethod.POST)
    public String insertMember(BitMemberVo m)
    {
        String str = "";
        str = bitdao.insertMember(m)+"";
        return str;
    }
}
