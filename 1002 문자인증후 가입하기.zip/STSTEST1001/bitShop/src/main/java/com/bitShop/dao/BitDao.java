package com.bitShop.dao;

import org.springframework.stereotype.Repository;

import com.bitShop.db.DBManager;
import com.bitShop.vo.BitMemberVo;

@Repository
public class BitDao {
	 public int insertMember(BitMemberVo m)
	    {
	        return DBManager.insertMember(m);
	    }
}
