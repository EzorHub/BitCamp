package com.bitShop.db;

import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.bitShop.vo.BitMemberVo;

public class DBManager {
	private static SqlSessionFactory factory;
    static {
        try {
            Reader reader= Resources.getResourceAsReader("com/bitShop/db/dbConfig.xml");
            factory = new SqlSessionFactoryBuilder().build(reader);
        } catch (Exception e) {
            // TODO: handle exception
            System.out.println(e.getMessage());
        }
    }
     
    public static int insertMember(BitMemberVo m)
    {
        int re  = 0;
        SqlSession session = factory.openSession(true);
        re = session.insert("bitmember.insert", m);
        session.close();
        return re;
    }
     
}
