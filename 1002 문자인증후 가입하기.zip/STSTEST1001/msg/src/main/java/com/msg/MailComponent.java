package com.msg;

import org.springframework.stereotype.Component;

@Component
public class MailComponent {
	
	//나는 sendComponent에서 다함

}
