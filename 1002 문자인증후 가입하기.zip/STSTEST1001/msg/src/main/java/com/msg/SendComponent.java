package com.msg;

import java.util.List;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.msg.dao.BitDao;
import com.msg.vo.BitMemberVo;

import kr.co.youiwe.webservice.ServiceSMSSoapProxy;


@Component
public class SendComponent {
@Autowired	
private BitDao bitdao;
public void setBitdao(BitDao bitdao) {
	this.bitdao = bitdao;
}

	/*
	 * @Bean private JavaMailSenderImpl javaMailSender() { JavaMailSenderImpl sender
	 * = new JavaMailSenderImpl(); sender.setHost(host); }
	 */
@Autowired
private JavaMailSenderImpl javaMailSender;
public void setJavaMailSender(JavaMailSenderImpl javaMailSender) {
	this.javaMailSender = javaMailSender;
}
	
	
	
	   
//@Scheduled(cron =  "0 0,15,30 * 1-30 * ?")

//@RequestMapping(value = "/send.do",method = {RequestMethod.GET, RequestMethod.POST})
public void send() {
	
	List<BitMemberVo> list = bitdao.listAll();
	System.out.println("size: "+list.size());
	for(BitMemberVo b :list) {
			sendSMS(b);
			sendEmail(b);
	      }
	
}
	
	@Bean //xml을대신하여객체를 생성해줌 - bean의 id는 메소드이름과 동일
	public static JavaMailSenderImpl javaMailSender() {
	      JavaMailSenderImpl r 
	      = new JavaMailSenderImpl();
	      //---------------------------------------------
	      //r.setHost("smtp.naver.com"); - 네이버
	      //r.setPort(465);
	      //r.setPort(587); - tls서버   
	      //r.setUsername("bsy62305");
	      //r.setPassword("");
	      //r.setDefaultEncoding("utf-8");      
	      //---------------------------------------------
	      
	      r.setHost("smtp.gmail.com");//구글
	      r.setPort(465);
	      //r.setPort(587); - tls서버   
	      r.setUsername("zo0313zo@gmail.com"); //구글은 이메일 전체씀
	      r.setPassword("");
	      r.setDefaultEncoding("utf-8");
	      //---------------------------------------------
	      
	      Properties prop = new Properties();      
	      prop.put("mail.smtp.ssl.enable", true);
	      //prop.put("mail.smtp.starttls.enable", true); //tls서버
	      prop.put("mail.smtp.auth", true);
	      prop.put("mail.smtp.ssl.checkserveridentity", true);
	      prop.put("mail.smtp.ssl.trust", "*");
	      
	      r.setJavaMailProperties(prop);
	      
	      return r;
	   }

	public void sendSMS(BitMemberVo b) {

		  SimpleMailMessage msg = new SimpleMailMessage();

	      String smsID = "rola";
	      String smsPW = "bit123400";
	      // 01025598279
	      String senderPhone = "01025598279";
          String receivePhone = b.getPhone();
          String smsContent = "[zozo]이용요금은 "+b.getPay()+"입니다. 조심히들어가세여...";
	      
	      ServiceSMSSoapProxy sendsms = new ServiceSMSSoapProxy();
	      try {
	            String test1 = (smsID + smsPW + receivePhone);
	            CEncrypt encrypt = new CEncrypt("MD5", test1);
	            java.lang.String send = sendsms.sendSMS(smsID, encrypt.getEncryptData(), senderPhone, receivePhone,
	                  smsContent);
	          
	            System.out.println("결과:" + send);
	         
	      } catch (Exception e) {
	         e.printStackTrace();  
	      }
	}

	public void sendEmail(BitMemberVo b) {
		
		SimpleMailMessage msg =  new SimpleMailMessage();
		msg.setSubject("[zozo]이용요금안내");
        msg.setFrom("zo0313zo@gmail.com");
        msg.setTo(b.getEmail());
        msg.setText("이번달 요금은 " + b.getPay() + "원 입니다");
        try {
        	javaMailSender.send(msg);
        }catch (Exception e) {
			e.printStackTrace();
		}

		
	}
}
