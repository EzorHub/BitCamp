package com.msg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.msg.CEncrypt;
import com.msg.dao.BitDao;
import com.msg.vo.BitMemberVo;

import kr.co.youiwe.webservice.ServiceSMSSoapProxy;

@Controller
public class BitController {
	
	@Autowired
	public BitDao bitdao;
	public void setBitdao(BitDao bitdao) {
		this.bitdao = bitdao;
	}
	
	@Autowired
	private JavaMailSender javaMailSender;
	public void setJavaMailSender(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}
	
	
	
	/*
	 * @ResponseBody
	 * 
	 * @RequestMapping("/send.do") public String mailPay() { String r = "";
	 * SimpleMailMessage msg = new SimpleMailMessage();
	 * 
	 * String smsID = "rola"; String smsPW = "bit123400"; // 01025598279
	 * ServiceSMSSoapProxy sendsms = new ServiceSMSSoapProxy(); try {
	 * 
	 * msg.setSubject("[zozo]이용요금안내"); msg.setFrom("zo0313zo@gmail.com");
	 * List<BitMemberVo> list = bitdao.listAll(); System.out.println(list); for
	 * (BitMemberVo b : list) { // 이메일 msg.setTo(b.getEmail());
	 * msg.setText("이번달 요금은 " + b.getPay() + "원 입니다");
	 * 
	 * javaMailSender.send(msg);
	 * 
	 * // 메세지 String senderPhone = "01025598279"; String receivePhone =
	 * b.getPhone(); String smsContent = "이용요금은 "+b.getPay()+"입니다."; String test1 =
	 * (smsID + smsPW + receivePhone); CEncrypt encrypt = new CEncrypt("MD5",
	 * test1); java.lang.String send = sendsms.sendSMS(smsID,
	 * encrypt.getEncryptData(), senderPhone, receivePhone, smsContent); r += send;
	 * System.out.println("결과:" + send); } } catch (Exception e) {
	 * e.printStackTrace(); } return r; }
	 */
	
	

}
