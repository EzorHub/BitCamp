


/*@Controller
public class SMSController {

	@RequestMapping(value = "smssend.do", method = RequestMethod.GET)
	public void form() {

	}

	@RequestMapping(value = "smssend.do", method = RequestMethod.POST)
	public String submit(String senderPhone, String receivePhone, String smsContent) {
		String r = "";

		String smsID= "rola";	
		String smsPW="bit123400";
		//01025598279 -teacher's phone: sender
		
		ServiceSMSSoapProxy sendsms = new ServiceSMSSoapProxy();
		try {
			System.out.println("보내는 번호를 입력하세요");
			 
			System.out.println("받는 번호를 입력하세요");
			 
			System.out.println("보내실내용을 입력하세요");
			 
			String test1 = (smsID + smsPW + receivePhone);
			CEncrypt encrypt = new CEncrypt("MD5", test1);
			java.lang.String send = sendsms.sendSMS(smsID, encrypt.getEncryptData(), senderPhone, receivePhone,
					smsContent);
			r = send;
			System.out.println("결과코드: " + send);
		} catch (Exception e) {
			System.out.println("Exception in main:" + e);
		}
		return r;

	}*/

//}
