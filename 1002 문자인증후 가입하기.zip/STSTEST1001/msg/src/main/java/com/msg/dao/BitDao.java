package com.msg.dao;

import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Repository;

import com.msg.db.DBManager;
import com.msg.vo.BitMemberVo;

@Repository
public class BitDao {
	public List<BitMemberVo> listAll(){
		return DBManager.listAll();
	}
	
	
}
