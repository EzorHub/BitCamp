package ex08;

public interface Filters {
	

	public void pro();
	
}
