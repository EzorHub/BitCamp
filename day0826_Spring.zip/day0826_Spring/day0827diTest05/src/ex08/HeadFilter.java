package ex08;



public class HeadFilter implements Filters{
	@Override
	public void pro() {
		// TODO Auto-generated method stub
		System.out.println("HeadFilter ó���Դϴ�.");
	}
}
