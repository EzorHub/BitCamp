package ex08;

public class ZipFilter implements Filters {

	@Override
	public void pro() {
		// TODO Auto-generated method stub

	}

}
