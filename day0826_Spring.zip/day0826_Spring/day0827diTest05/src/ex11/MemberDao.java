package ex11;

public interface MemberDao {
	public void insertMember();
}
