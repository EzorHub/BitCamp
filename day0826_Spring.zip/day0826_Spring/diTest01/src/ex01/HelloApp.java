package ex01;

public class HelloApp {

	public static void main(String[] args) {

		//MessageBean bean = new MessageBean();
		MessageBeanEn bean = new MessageBeanEn();
		bean.sayHello("Ʃ��");
		
	}

}
