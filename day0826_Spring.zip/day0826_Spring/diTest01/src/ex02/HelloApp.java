package ex02;

public class HelloApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MessageBean msg1 = new MessageBeanEn();
		msg1.sayHello("Zoe");
		MessageBean msg2 = new MessageBeanKo();
		msg2.sayHello("Ʃ��");
	}

}
