package ex03;

public class MessageBeanSp implements MessageBean {

	@Override
	public void sayHello(String name) {
		// TODO Auto-generated method stub
		System.out.println("Hola, "+name);
	}

}
