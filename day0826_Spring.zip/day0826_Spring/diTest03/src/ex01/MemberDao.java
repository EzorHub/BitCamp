package ex01;

public interface MemberDao {
	public void insertMember();
}
