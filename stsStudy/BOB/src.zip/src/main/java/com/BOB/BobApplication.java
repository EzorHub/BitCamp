package com.BOB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BobApplication {

	public static void main(String[] args) {
		SpringApplication.run(BobApplication.class, args);
	}

}
