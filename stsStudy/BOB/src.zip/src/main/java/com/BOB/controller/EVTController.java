package com.BOB.controller;

import org.springframework.stereotype.Controller;

@Controller
public class EVTController {

}
